sampleSplitting
===========

Calculates sample bottle volumes for a given USGS station and storm event(s)

To install this package use the following code:
install.packages("sampleSplitting",repos="http://usgs-r.github.com",type="source")
