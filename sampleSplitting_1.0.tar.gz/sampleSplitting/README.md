sampleSplitting
===========

Calculates sample bottle volumes for a given USGS station and storm event(s)

To install this package use the following code:
library(devtools)
install_github("jlthomps/SampleSplitting")

An example workflow script is available at https://github.com/jlthomps/SampleSplitting/blob/master/sampleSplitWorkflow.R
